package com.kaactueail.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kaactueail.dao.MemberDAO;

@Controller
public class formController {

	//@Inject
	@Autowired
	MemberDAO Dao;
	
	//아이디 중복체크
	@RequestMapping(value = "/checkid", method = {RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody int idCheck(String mId) {
		if(mId == null || mId == "")
			return -1;
		else
		return Dao.checkId(mId);
	}
	
	//권한에 따라서 보는 페이지 바뀜
	@RequestMapping("/main")
	public String mainPage(HttpSession session) {
		try {
		if(session.getAttribute("mRole").equals("ROLE_ADMIN")) return "admin/main";
		else if(session.getAttribute("mRole").equals("ROLE_USER")) return "user/main";
		else return "sign/no";
		}
		catch (Exception e){
			return "error";
		}
	}
	
	
	@RequestMapping("/signupform")
	public String signupForm() {
		return "sign/signupform";
	}
	
	@RequestMapping("/loginform")
	public String loginForm() {
		return "sign/loginform";
	}
	
	
}
